<?php include('header.php'); ?>
<form action="index.php" method="post">
    <label for="name">نام</label> <br>
    <input type="text" name="name" id="name"> <br><br>

    <label for="pass">کلمه عبور</label><br>
    <input type="password" name="pass" id="pass"><br><br>

    <label for="gender">جنسیت</label><br>
    مرد<input type="radio" name="gender" id="gender" value="مرد"><br>
    زن<input type="radio" name="gender" id="gender" value="زن"><br><br>

    <label for="fav">علاقه مندی ها</label><br>
    موسیقی<input type="radio" id="fav" value="موسیقی"><br>
    ورزش<input type="radio" id="fav" value="ورزش"><br><br>

    <label for="file">تصویر</label><br>
    <input type="file" name="file" id="file"><br><br>

    <input type="submit" value="ارسال فرم">
    <input type="reset" value="پاک کردن فرم">

</form>
<?php include('footer.php'); ?>