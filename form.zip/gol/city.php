<?php

$city = [
    '1' => 'یزد',
    '2' => 'اصفهان',
    '3' => 'تهران',
    '4' => 'امریکای کسافت امریکای کسافت'
];
asort($city);
?>
<select name="city">
    <?php
    foreach ($city as $id => $shaher) { ?>
        <option value="<?= $id ?>">
            <?= $shaher ?>
        </option>
    <?php } ?>
</select>
