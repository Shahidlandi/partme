</div>
    <div class="footer">
        <p>طراحی سایت توسط هنرجویان عزیز</p>
    </div>
</body>
</html>