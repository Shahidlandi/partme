<?php
include('header.php');
$user = $_POST['user'];
$pass = $_POST['pass'];
if ($user == 'admin' && $pass == '123456') {
    print "welcome is $user";
} else {
    print "forget password";
}
// print"user name is $user";
// print"password is $pass";
include('footer.php');
