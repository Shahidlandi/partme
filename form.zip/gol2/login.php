<?php include('header.php'); ?>

<form action="./index.php" method="post">

    <label for="user">ورود</label> <br>
    <input type="text" name="user" id="user" required><br><br>

    <label for="pass">رمز عبور</label><br>
    <input type="password" name="pass" id="pass" required><br><br>
    <input type="submit" value="send">
</form>
<?php include('footer.php'); ?>