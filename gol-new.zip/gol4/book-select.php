<?php
$books = $_POST['books'];

print_r($books);
