<?php
$cover_name = $_FILES['cover']['name'];
$cover_type = $_FILES['cover']['type'];
$cover_size = $_FILES['cover']['size'];
$cover_tmp_name = $_FILES['cover']['tmp_name'];

// --------------------------------------------------------

$content_name = $_FILES['content']['name'];
$content_type = $_FILES['content']['type'];
$content_size = $_FILES['content']['size'];
$content_tmp_name = $_FILES['content']['tmp_name'];



$error = [];


$cover_arr = explode('.',$cover_name);
$cover_pasvand = end($cover_arr);

$content_arr = explode('.',$content_name);
$content_pasvand = end($content_arr);


if($content_pasvand != "png" || $cover_pasvand != "jpg"){
    $error[]="فرمت تصویر اشتباه است";
}

if($cover_size > 100*1024){
    $error[]="اندازه تصویر بیش از حد مجاز است";
}

if($cover_size > 500*1024){
    $error[]="اندازه متن محتوا بیش از حد مجاز است";
}

if(count($error) == 0){
    move_uploaded_file($content_tmp_name ,"file/$content_name");
    move_uploaded_file($cover_tmp_name ,"file/$cover_name");
}else{
    foreach ($error as $err) {
        print"<li>$err</li>";
    }
}