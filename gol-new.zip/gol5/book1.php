<form action="book2.php" method="post" enctype="multipart/form-data">
    <label for="user">نام جلد :</label><br>
    <input type="text" name="user" id="user"><br><br>

    <label for="cover">تصویر جلد :</label><br>
    <input type="file" name="cover" id="cover"><br><br>
    
    <label for="content">متن کتاب :</label><br>
    <input type="file" name="content" id="content"><br><br>

    <input type="submit" value="ارسال">
    <input type="reset" value="بازنویسی">
</form>