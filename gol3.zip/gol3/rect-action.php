<?php 
$tole = $_POST['tole'];
$arz = $_POST['arz'];

$sum = $tole*$arz;
print "tole shoma = $sum";

?>