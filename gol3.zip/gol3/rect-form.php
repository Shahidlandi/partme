<form action="./rect-action.php" method="post">
    <label for="tole">طول</label><br>
    <input type="text" name="tole" id="tole"><br><br>
    <label for="arz">عرض</label><br>
    <input type="text" name="arz" id="arz"><br><br>
    <input type="submit" value="send">
</form>